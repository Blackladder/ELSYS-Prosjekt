"""
STK - A collection of libraries useful for making apps with NAOqi.
"""
